package com.poly3d.studio;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.view.DisplayCutout;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 1001;
    private WebView web;
    private FrameLayout root;
    private boolean fullscreen = true;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        web = new WebView(this);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF16181C);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        // отступы только под вырез камеры, чтобы кнопки не прятались
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int l = 0, t = 0, r = 0, b = 0;
            if (Build.VERSION.SDK_INT >= 28) {
                DisplayCutout c = ins.getDisplayCutout();
                if (c != null) { l = c.getSafeInsetLeft(); t = c.getSafeInsetTop(); r = c.getSafeInsetRight(); b = c.getSafeInsetBottom(); }
            }
            if (!fullscreen && Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets sb = ins.getInsets(WindowInsets.Type.systemBars());
                l = Math.max(l, sb.left); t = Math.max(t, sb.top); r = Math.max(r, sb.right); b = Math.max(b, sb.bottom);
            }
            v.setPadding(l, t, r, b);
            return ins;
        });
        applySystemUi();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Открыть файл"), PICK_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (state != null) web.restoreState(state);
        else web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == PICK_FILE && fileCallback != null) {
            Uri[] result = null;
            if (res == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applySystemUi();
    }

    /** Полноэкранный режим: панели телефона скрыты, появляются по свайпу от края */
    @SuppressWarnings("deprecation")
    private void applySystemUi() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                if (fullscreen) {
                    c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                } else c.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            }
        } else {
            View d = getWindow().getDecorView();
            d.setSystemUiVisibility(fullscreen
                ? View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                  | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                : 0);
        }
        if (root != null) root.requestApplyInsets();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.onAndroidBack&&window.onAndroidBack())?'1':'0'", value -> {
            if (value == null || !value.contains("1")) exitApp();
        });
    }

    private void exitApp() {
        super.onBackPressed();
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    private final java.util.Map<Integer, OutputStream> streams = new java.util.HashMap<>();
    private final java.util.Map<Integer, String> paths = new java.util.HashMap<>();
    private int nextStream = 1;

    private OutputStream openDownload(String name, String mime, String[] where) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Poly3D");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new Exception("нет доступа к Загрузкам");
            where[0] = "Загрузки/Poly3D/" + name;
            return getContentResolver().openOutputStream(uri);
        }
        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Poly3D");
        dir.mkdirs();
        File f = new File(dir, name);
        where[0] = f.getAbsolutePath();
        return new FileOutputStream(f);
    }

    /** Мост для сохранения файлов из JS */
    class Bridge {
        @JavascriptInterface
        public void setFullscreen(boolean on) {
            runOnUiThread(() -> { fullscreen = on; applySystemUi(); });
        }

        @JavascriptInterface
        public void keepAwake(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        /** Потоковое сохранение больших файлов (видео): beginFile → appendFile… → finishFile */
        @JavascriptInterface
        public int beginFile(String name, String mime) {
            try {
                String[] where = new String[1];
                OutputStream os = openDownload(name, mime, where);
                synchronized (streams) {
                    int id = nextStream++;
                    streams.put(id, os);
                    paths.put(id, where[0]);
                    return id;
                }
            } catch (Exception e) {
                toast("Ошибка сохранения: " + e.getMessage());
                return -1;
            }
        }

        @JavascriptInterface
        public void appendFile(int id, String base64) {
            try {
                OutputStream os;
                synchronized (streams) { os = streams.get(id); }
                if (os != null) os.write(Base64.decode(base64, Base64.DEFAULT));
            } catch (Exception e) {
                toast("Ошибка записи: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void finishFile(int id) {
            try {
                OutputStream os;
                String where;
                synchronized (streams) { os = streams.remove(id); where = paths.remove(id); }
                if (os != null) { os.close(); toast("Сохранено: " + where); }
            } catch (Exception e) {
                toast("Ошибка сохранения: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void saveFile(String name, String base64, String mime) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                String where;
                OutputStream os;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Poly3D");
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) throw new Exception("нет доступа к Загрузкам");
                    os = getContentResolver().openOutputStream(uri);
                    where = "Загрузки/Poly3D/" + name;
                } else {
                    File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Poly3D");
                    dir.mkdirs();
                    File f = new File(dir, name);
                    os = new FileOutputStream(f);
                    where = f.getAbsolutePath();
                }
                os.write(bytes);
                os.close();
                toast("Сохранено: " + where);
            } catch (Exception e) {
                toast("Ошибка сохранения: " + e.getMessage());
            }
        }
    }
}
