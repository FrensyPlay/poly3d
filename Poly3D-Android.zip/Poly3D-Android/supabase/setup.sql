-- Poly3D Studio: хранилище проектов. Каждый пользователь видит только свою папку projects/<user_id>/
insert into storage.buckets (id, name, public, file_size_limit)
values ('projects', 'projects', false, 52428800)
on conflict (id) do update set file_size_limit = excluded.file_size_limit;

drop policy if exists "poly3d read own" on storage.objects;
drop policy if exists "poly3d insert own" on storage.objects;
drop policy if exists "poly3d update own" on storage.objects;
drop policy if exists "poly3d delete own" on storage.objects;

create policy "poly3d read own" on storage.objects for select to authenticated
  using (bucket_id = 'projects' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "poly3d insert own" on storage.objects for insert to authenticated
  with check (bucket_id = 'projects' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "poly3d update own" on storage.objects for update to authenticated
  using (bucket_id = 'projects' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "poly3d delete own" on storage.objects for delete to authenticated
  using (bucket_id = 'projects' and (storage.foldername(name))[1] = auth.uid()::text);
