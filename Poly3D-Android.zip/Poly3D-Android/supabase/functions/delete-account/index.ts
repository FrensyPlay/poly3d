// Удаление аккаунта Poly3D Studio вместе с проектами в облаке (требование магазинов приложений)
const SB = Deno.env.get("SUPABASE_URL")!;
const SR = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const H = { apikey: SR, Authorization: `Bearer ${SR}`, "Content-Type": "application/json" };
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...CORS, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const auth = req.headers.get("Authorization") || "";
  const ur = await fetch(`${SB}/auth/v1/user`, { headers: { apikey: SR, Authorization: auth } });
  const user = await ur.json();
  if (!ur.ok || !user?.id) return json({ error: "Нужно войти в аккаунт" }, 401);
  const list = await (await fetch(`${SB}/storage/v1/object/list/projects`, { method: "POST", headers: H, body: JSON.stringify({ prefix: user.id, limit: 1000 }) })).json();
  if (Array.isArray(list) && list.length)
    await fetch(`${SB}/storage/v1/object/projects`, { method: "DELETE", headers: H, body: JSON.stringify({ prefixes: list.map((o: { name: string }) => `${user.id}/${o.name}`) }) });
  const del = await fetch(`${SB}/auth/v1/admin/users/${user.id}`, { method: "DELETE", headers: H });
  if (!del.ok) return json({ error: "Не удалось удалить пользователя" }, 500);
  return json({ ok: true });
});
