// Вход через VK ID для Poly3D Studio.
// 1) Приложение открывает эту функцию в браузере -> редирект на id.vk.com (OAuth 2.1 + PKCE)
// 2) VK возвращает code + device_id -> меняем на токен, берём профиль
// 3) Создаём/находим пользователя Supabase и выдаём сессию -> возвращаем в приложение poly3d://auth
const SB = Deno.env.get("SUPABASE_URL")!;
const SR = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const VK = Deno.env.get("VK_CLIENT_ID") ?? "";
const H = { apikey: SR, Authorization: `Bearer ${SR}`, "Content-Type": "application/json" };

const b64u = (a: Uint8Array) => btoa(String.fromCharCode(...a)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const page = (title: string, body: string, link = "") => new Response(
  `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title>
<style>body{font-family:system-ui,sans-serif;background:#16181c;color:#eee;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0;text-align:center}
a.b{display:inline-block;margin-top:18px;padding:14px 22px;border-radius:12px;background:#ff8a2a;color:#111;font-weight:700;text-decoration:none;font-size:18px}</style></head>
<body><div><h2>${title}</h2><p>${body}</p>${link ? `<a class="b" href="${link}">Вернуться в Poly3D Studio</a><script>setTimeout(()=>{location.href=${JSON.stringify(link)}},300)</script>` : ""}</div></body></html>`,
  { headers: { "Content-Type": "text/html; charset=utf-8" } });

Deno.serve(async (req) => {
  const u = new URL(req.url);
  const self = `${SB}/functions/v1/vk-auth`;
  if (!VK) return page("VK не настроен", "Добавьте секрет VK_CLIENT_ID в проект Supabase.");
  const code = u.searchParams.get("code");
  if (!code) {
    // шаг 1: отправляем пользователя на VK ID
    const verifier = b64u(crypto.getRandomValues(new Uint8Array(32)));
    const challenge = b64u(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier))));
    const a = new URL("https://id.vk.com/authorize");
    a.search = new URLSearchParams({ response_type: "code", client_id: VK, redirect_uri: self, state: verifier,
      code_challenge: challenge, code_challenge_method: "S256", scope: "email" }).toString();
    return Response.redirect(a.toString(), 302);
  }
  try {
    const state = u.searchParams.get("state") ?? "", device_id = u.searchParams.get("device_id") ?? "";
    const tr = await fetch("https://id.vk.com/oauth2/auth", { method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ grant_type: "authorization_code", code, code_verifier: state, client_id: VK, device_id, redirect_uri: self, state }) });
    const tj = await tr.json();
    if (!tj.access_token) return page("Не получилось войти", "VK ответил: " + (tj.error_description || tj.error || tr.status));
    const ui = await (await fetch("https://id.vk.com/oauth2/user_info", { method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ client_id: VK, access_token: tj.access_token }) })).json();
    const vu = ui.user || {};
    const vkid = String(vu.user_id || tj.user_id || "");
    if (!vkid) return page("Не получилось войти", "VK не вернул профиль.");
    const email = String(vu.email || tj.email || `vk${vkid}@vk.poly3d.app`).toLowerCase();
    const meta = { full_name: `${vu.first_name || ""} ${vu.last_name || ""}`.trim(), avatar_url: vu.avatar || null, provider: "vk", vk_id: vkid };
    // создаём пользователя (если уже есть — Supabase вернёт ошибку, это нормально)
    await fetch(`${SB}/auth/v1/admin/users`, { method: "POST", headers: H, body: JSON.stringify({ email, email_confirm: true, user_metadata: meta }) });
    const gl = await (await fetch(`${SB}/auth/v1/admin/generate_link`, { method: "POST", headers: H, body: JSON.stringify({ type: "magiclink", email }) })).json();
    const hashed = gl.hashed_token || gl.properties?.hashed_token;
    if (!hashed) return page("Не получилось войти", "Сервер не выдал ссылку входа.");
    const sv = await (await fetch(`${SB}/auth/v1/verify`, { method: "POST", headers: H, body: JSON.stringify({ type: "magiclink", token_hash: hashed }) })).json();
    if (!sv.access_token) return page("Не получилось войти", "Не удалось создать сессию: " + (sv.msg || sv.error_description || ""));
    const back = "poly3d://auth?" + new URLSearchParams({ access_token: sv.access_token, refresh_token: sv.refresh_token, expires_in: String(sv.expires_in || 3600) }).toString();
    return page("Готово!", "Вы вошли через VK. Возвращаемся в приложение…", back);
  } catch (e) {
    return page("Ошибка", String(e));
  }
});
